#!/bin/bash
# Cron job script to run port_check periodically

/usr/bin/port_check --hosts "example.com,8.8.8.8" --log /var/log/port_check.log --quiet