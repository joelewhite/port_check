# Port Check (`port_check.sh`)

A lightweight TCP/UDP port scanner using Bash-only logic and `/dev/tcp` and `/dev/udp`.

## Features

- No external dependencies (no `nmap`, `netcat`, or `telnet` needed)
- Supports TCP and UDP
- Color-coded output
- Optional logging with CSV mirroring
- Supports `--quiet` for silent operation
- Portable and ideal for minimal Linux environments

## Usage

```bash
./port_check.sh --hosts "host1,host2" [--ports "22,80"] [--udp] [--log /path/to/logfile] [--quiet]
```

## Options

| Option      | Description                                                  |
|-------------|--------------------------------------------------------------|
| `--hosts`   | Required. Comma or space-separated list of IPs or hostnames. |
| `--ports`   | Optional. Comma/space-separated ports. Defaults: 22,80,443.  |
| `--udp`     | Optional. Scan ports using UDP instead of TCP.               |
| `--log`     | Optional. Log output to a specified file and generate CSV.   |
| `--quiet`   | Optional. Suppresses terminal output when logging is enabled.|
| `--help`    | Optional. Shows this help message.                           |

## Example

Scan ports 22 and 80 on google.com:
```bash
./port_check.sh --hosts google.com --ports 22,80
```

Scan common UDP ports on multiple hosts:
```bash
./port_check.sh --hosts "dns1.com,dns2.com" --ports "53,161" --udp
```

Log results silently:
```bash
./port_check.sh --hosts "server1" --log scan.txt --quiet
```

## License

MIT License  
Author: Joel E. White
